export interface City {
    id: number;
    name: string;
    weather: string;
    
}
