export class User {
    name!: string;
    password!: string;
    country!:string;
    city!:string
}
